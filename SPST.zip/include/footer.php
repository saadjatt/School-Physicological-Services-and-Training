 <footer id="footer">
 
		<div class="container">
   <div class="row text-center">
 		<p>
 			<img width="100" src="assets/images/logo.png" alt="SPST logo">
 		</p>	
          <b class="logo-title " >School Physicological Services and Training</b>
</div>
			

			<div class="clear"></div>
			<!--CLEAR FLOATS-->
		</div>
		<div class="footer2">
			<div class="container">
				<div class="row">

					<div class="col-md-6 panel">
						<div class="panel-body">
							
							<p class="simplenav">
								<a href="index.php">Home</a> | 
								<a href="services.php">Services</a> |
								
								<a href="about.php">About</a> |
								
								<a href="contact.php">Contact</a>
							</p>
						</div>
					</div>

					<div class="col-md-6 panel">
						<div class="panel-body">
							<p class="text-right">
								<span>&copy; SPST.pk 2020 All right reserved. 
							</p>
						</div>
					</div>

				</div>
				<!-- /row of panels -->
			</div>
		</div>
	</footer>
